﻿namespace Restaurant
{
    public class Potato : Vegetable
    {
    }
}
