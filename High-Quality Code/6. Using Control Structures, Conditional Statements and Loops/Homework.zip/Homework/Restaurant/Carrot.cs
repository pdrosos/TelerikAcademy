﻿namespace Restaurant
{
    public class Carrot : Vegetable
    {
    }
}
