﻿namespace Restaurant
{
    public class Vegetable
    {
    }
}
