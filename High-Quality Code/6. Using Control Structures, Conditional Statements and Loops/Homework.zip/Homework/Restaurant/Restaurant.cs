﻿namespace Restaurant
{
    public class Restaurant
    {
        public static void Main(string[] args)
        {
            Chef chef = new Chef();
            chef.Cook();
        }
    }
}
