﻿namespace People
{
    public enum Gender 
    { 
        Male, 
        Female 
    }
}
