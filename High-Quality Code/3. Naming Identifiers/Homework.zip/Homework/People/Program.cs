﻿namespace People
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine(Person.MakePerson(21));
        }
    }
}
