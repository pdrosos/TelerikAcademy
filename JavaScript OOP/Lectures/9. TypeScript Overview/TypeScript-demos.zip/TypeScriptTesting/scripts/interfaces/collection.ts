﻿interface StringCollection {
    [index: string]: string
}