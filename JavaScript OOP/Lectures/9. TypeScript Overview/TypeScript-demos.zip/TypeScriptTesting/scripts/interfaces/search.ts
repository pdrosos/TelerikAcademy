﻿interface SearchFunc {
    (name: string) : Array<Object>;
}