﻿interface Vehicle {
    engine: Engine;
    doors: number;
    wheels: number;
    driver: Driver;
} 