#include <iostream>
#define MAXN 1024
using namespace std;
long long Fibonacci(int n)
{
    long long f0 = 0;
    long long f1 = 1;
    for(int i = 2; i <= n; i++)
    {
        long long newFib = f0 + f1;
        f0 = f1;
        f1 = newFib;
    }
    return f1;
}
int main()
{
    int n = 41;
    // cin >> n;
    cout << Fibonacci(n) << endl;
}
