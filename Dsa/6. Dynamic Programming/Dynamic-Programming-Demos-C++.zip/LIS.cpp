#include <iostream>
using namespace std;
int main()
{
    int N = 9;
    int S[] = {2, 4, 3, 5, 1, 7, 6, 9, 8};
    int maxLength = 1, bestEnd = 0;
    int L[N], P[N];
    L[0] = 1;
    P[0] = -1;
    for (int i = 1; i < N; i++)
    {
       L[i] = 1;
       P[i] = -1;
       for (int j = i - 1; j >= 0; j--)
       {
          if (L[j] + 1 > L[i] && S[j] < S[i])
          {
             L[i] = L[j] + 1;
             P[i] = j;
          }
       }
       if (L[i] > maxLength)
       {
          bestEnd = i;
          maxLength = L[i];
       }
    }
    cout << "Max length: " << maxLength << endl;
    cout << "Sequence end index: " << bestEnd << endl;
    cout << "Longest subsequence:";
    int ind = bestEnd;
    while(ind != -1)
    {
        cout << " " << S[ind];
        ind = P[ind];
    }
    cout << endl;
}
