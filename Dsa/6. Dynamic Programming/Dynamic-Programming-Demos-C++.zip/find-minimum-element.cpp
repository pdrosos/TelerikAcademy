#include <iostream>
using namespace std;
int find_min(int arr[], int n)
{
    int min = arr[0];
    for(int i = 1; i < n; i++)
        if (arr[i] < min)
            min = arr[i];
    return min;
}
int main()
{
    int arr[] = { 0, -1, 5, 101, -16, 12, 13, 10, 2, 5 };
    cout << find_min(arr, 10) << endl;
    return 0;
}
