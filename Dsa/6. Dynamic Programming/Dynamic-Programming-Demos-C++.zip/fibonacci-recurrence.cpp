#include <iostream>
using namespace std;
// n = 34 - 0.210 sec.
// n = 35 - 0.334 sec.
// n = 36 - 0.450 sec.
// n = 37 - 0.735 sec.
// n = 38 - 1.143 sec.
// n = 39 - 1.700 sec.
// n = 40 - 2.759 sec.
// n = 41 - 4.609 sec.
int calls = 0;
long long Fibonacci(int n)
{
    calls++;
    if (n == 0) return 0;
    if (n == 1) return 1;
    return Fibonacci(n - 1) + Fibonacci(n - 2);
}
int main()
{
    int n = 41;
    // cin >> n;
    cout << Fibonacci(n) << endl;
    cout << "calls: " << calls << endl;
}
