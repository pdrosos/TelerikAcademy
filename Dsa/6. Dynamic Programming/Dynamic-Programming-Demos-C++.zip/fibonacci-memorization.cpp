#include <iostream>
#define MAXN 1024
using namespace std;
long long memo[MAXN];
// n = 41 - 0.038 sec.
// n = 92 - 0.039 sec.
// n = 93 - 0.039 sec. - WRONG ANSWER
// n = 100 - 0.040 sec. - WRONG ANSWER
// n = 1002 - 0.045 sec. - WRONG ANSWER
int calls = 0;
long long Fibonacci(int n)
{
    calls++;
    if (memo[n] != 0) return memo[n];
    if (n == 0) return 0;
    if (n == 1) return 1;
    memo[n] = Fibonacci(n - 1) + Fibonacci(n - 2);
    return memo[n];
}
int main()
{
    int n = 41;
    // cin >> n;
    cout << Fibonacci(n) << endl;
    cout << "calls: " << calls << endl;
}
