#include <iostream>
using namespace std;
int find_max(int arr[], int n)
{
    int max = arr[0];
    for(int i = 1; i < n; i++)
        if (arr[i] > max)
            max = arr[i];
    return max;
}
int main()
{
    int arr[] = { 0, -1, 5, 101, -16, 12, 13, 10, 2, 5 };
    cout << find_max(arr, 10) << endl;
    return 0;
}
