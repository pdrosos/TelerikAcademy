#include <iostream>
#define MAXN 1024
using namespace std;
long long Fibonacci(int n)
{
    long long dp[MAXN];
    dp[0] = 0;
    dp[1] = 1;
    for(int i = 2; i <= n; i++)
    {
        dp[i] = dp[i-1] + dp[i-2];
    }
    return dp[n];
}
int main()
{
    int n = 41;
    // cin >> n;
    cout << Fibonacci(n) << endl;
}
