#include <iostream>
#define OFFSET 10000
using namespace std;
int possible[OFFSET + OFFSET];
int main()
{
    int N = 3;
    int nums[] = { 2, 7, -3 };
    int minpos = nums[0];
    int maxpos = nums[0];
    for(int i = 0; i < N; i++)
    {
        int newminpos = minpos, newmaxpos = maxpos;
        int newpossible[OFFSET + OFFSET] = { 0 };
        for(int j = maxpos; j >= minpos; j--) // j = one possible sum
        {
            if (possible[j+OFFSET] == 1) newpossible[j+nums[i]+OFFSET] = 1;
            if (j+nums[i] > newmaxpos) newmaxpos = j+nums[i];
            if (j+nums[i] < newminpos) newminpos = j+nums[i];
        }
        minpos = newminpos;
        maxpos = newmaxpos;
        for(int j = maxpos; j >= minpos; j--)
            if (newpossible[j+OFFSET] == 1)
                possible[j+OFFSET] = 1;
        if (nums[i] > maxpos) maxpos = nums[i];
        if (nums[i] < minpos) minpos = nums[i];
        possible[nums[i]+OFFSET] = 1;
    }

    cout << "Numbers: ";
    for(int i = 0; i < N; i++)
    {
        cout << nums[i] << " ";
    }
    cout << endl;

    int S = 6;

    if (possible[0+OFFSET]) cout << "Sum 0 is possible" << endl;
    else cout << "Sum 0 is not possible" << endl;

    if (possible[S+OFFSET]) cout << "Sum " << S << " is possible" << endl;
    else cout << "Sum " << S << " is not possible" << endl;

    cout << "Possible sums:";
    for(int i = minpos; i <= maxpos; i++)
    {
        if (possible[i+OFFSET] == 1) cout << " " << i;
    }
}
