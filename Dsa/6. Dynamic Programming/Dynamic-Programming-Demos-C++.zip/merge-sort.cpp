#include <iostream>
#define NUMBERS_COUNT 5
using namespace std;
int temp[NUMBERS_COUNT];

void merge(int numbers[], int left, int mid, int right)
{
  int i, left_end, num_elements, tmp_pos;

  left_end = (mid - 1);
  tmp_pos = left;
  num_elements = (right - left + 1);

  while ((left <= left_end) && (mid <= right))
  {
    if (numbers[left] <= numbers[mid])
    {
      temp[tmp_pos] = numbers[left];
      tmp_pos += 1;
      left += 1;
    }
    else
    {
      temp[tmp_pos] = numbers[mid];
      tmp_pos += 1;
      mid += 1;
    }
  }

  while (left <= left_end)
  {
    temp[tmp_pos] = numbers[left];
    left += 1;
    tmp_pos += 1;
  }
  while (mid <= right)
  {
    temp[tmp_pos] = numbers[mid];
    mid += 1;
    tmp_pos += 1;
  }

  //modified
  for (i=0; i < num_elements; i++)
  {
    numbers[right] = temp[right];
    right -= 1;
  }
}

void m_sort(int numbers[], int left, int right)
{
    if (right > left)
    {
        int mid = (right + left) / 2;
        m_sort(numbers, left, mid);
        m_sort(numbers, (mid+1), right);
        merge(numbers, left, (mid+1), right);
    }
}

void mergeSort(int numbers[], int array_size)
{
  m_sort(numbers, 0, array_size - 1);
}

int main()
{
	int arrayOne[NUMBERS_COUNT] = {65, 72, 105, 55, 2};

	mergeSort(arrayOne, NUMBERS_COUNT);

	for (int i = 0; i < NUMBERS_COUNT; i++)
	{
			cout << arrayOne[i] << " ";
	}

	return 0;
}
