﻿/*jslint browser: true*/

(function () {
    'use strict';

    /**
     * Redirect to Task One
     */
    window.location.href = 'odd-or-even.html';
}());