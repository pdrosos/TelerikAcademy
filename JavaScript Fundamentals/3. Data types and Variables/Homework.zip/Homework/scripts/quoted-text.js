﻿/*jslint browser: true*/
/*global jsConsole*/

(function () {
    'use strict';

    /**
     * Task Two
     * 
     * Create a string variable with quoted text in it. 
     * For example: 'How you doin'?', Joey said.
     */
    var quotedString = "'How you doin'?', Joey said";

    jsConsole.writeLine('Quoted string: ' + quotedString);
}());