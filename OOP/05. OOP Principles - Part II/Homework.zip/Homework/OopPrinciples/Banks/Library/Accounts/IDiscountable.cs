﻿namespace Banks.Library.Accounts
{
    interface IDiscountable
    {
        uint DiscountMonths
        {
            get;
            set;
        }
    }
}
