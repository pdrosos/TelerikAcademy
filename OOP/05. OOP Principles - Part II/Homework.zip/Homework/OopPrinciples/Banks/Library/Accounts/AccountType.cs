﻿namespace Banks.Library.Accounts
{
    public enum AccountType
    {
        Deposit,
        Mortgage,
        Loan,
    }
}