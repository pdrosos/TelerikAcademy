﻿using System;

public enum Customer
{
    Individual, Company
}
