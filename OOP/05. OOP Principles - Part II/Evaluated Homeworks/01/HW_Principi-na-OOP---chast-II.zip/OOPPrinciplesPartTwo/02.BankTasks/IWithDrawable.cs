﻿using System;

interface IWithDrawable
{
    void WithDrawMoney(double sum);
}
