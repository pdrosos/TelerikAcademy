﻿using System;

interface IDepositable
{
    void DepositMoney(double sum);
}
