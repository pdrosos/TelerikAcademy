﻿namespace Animals
{
    public enum Sex
    {
        Male,
        Female
    }
}