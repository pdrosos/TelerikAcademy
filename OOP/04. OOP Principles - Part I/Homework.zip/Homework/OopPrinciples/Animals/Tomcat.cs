﻿namespace Animals
{
    /// <summary>
    /// Tomcat
    /// </summary>
    public class Tomcat : Cat
    {
        public Tomcat(string name, double age) : base(name, age, Sex.Male)
        {
        }
    }
}
