﻿namespace Animals
{
    public interface ISound
    {
        string ProduceSound();
    }
}
