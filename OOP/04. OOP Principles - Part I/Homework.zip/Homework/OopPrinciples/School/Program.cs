﻿namespace School
{
    using System;

    class Program
    {
        static void Main()
        {
            School school = SchoolTest.CreateSchool();
            Console.WriteLine(school);
        }
    }
}
