﻿namespace School
{
    using System;

    public interface ICommentable
    {
        string Comment
        {
            get;
            set;
        }       
    }
}
