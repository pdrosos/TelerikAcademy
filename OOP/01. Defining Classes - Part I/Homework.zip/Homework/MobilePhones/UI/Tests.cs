﻿namespace MobilePhones.UI
{
    using System;

    class Tests
    {
        static void Main(string[] args)
        {
            GsmTest.Test();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            GsmCallHistoryTest.Test();
        }
    }
}
