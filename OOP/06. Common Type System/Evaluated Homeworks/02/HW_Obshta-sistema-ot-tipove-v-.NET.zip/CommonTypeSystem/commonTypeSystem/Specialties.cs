﻿
public enum Specialties
{
    Biotechnology, Chemistry, ComputerSystems, History, Unspecified
}

