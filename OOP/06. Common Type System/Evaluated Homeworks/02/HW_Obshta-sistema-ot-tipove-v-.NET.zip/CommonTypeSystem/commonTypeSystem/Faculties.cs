﻿using System;

public enum Faculties
{
    HistoryFaculty,
    PhilosophyFaculty,
    MathematicsAndInformaticsFaculty
}

