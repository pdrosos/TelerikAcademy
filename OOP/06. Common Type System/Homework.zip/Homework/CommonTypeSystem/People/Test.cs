﻿namespace People
{
    using System;

    class Test
    {
        static void Main(string[] args)
        {
            Person person = new Person("Ivan");
            Console.WriteLine(person);
        }
    }
}
