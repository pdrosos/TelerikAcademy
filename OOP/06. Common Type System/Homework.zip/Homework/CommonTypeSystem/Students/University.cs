﻿namespace Students
{
    using System;

    public enum University
    {
        UniversityOne, UniversityTwo, UniversityThree
    }
}