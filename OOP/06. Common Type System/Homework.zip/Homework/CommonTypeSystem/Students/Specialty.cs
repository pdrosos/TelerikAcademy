﻿namespace Students
{
    using System;

    public enum Specialty
    {
        SpecialtyOne, SpecialtyTwo, SpecialtyThree
    }
}