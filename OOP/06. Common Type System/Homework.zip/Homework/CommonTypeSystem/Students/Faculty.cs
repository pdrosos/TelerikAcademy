﻿namespace Students
{
    using System;

    public enum Faculty
    {
        FacultyOne, FacultyTwo, FacultyThree
    }
}