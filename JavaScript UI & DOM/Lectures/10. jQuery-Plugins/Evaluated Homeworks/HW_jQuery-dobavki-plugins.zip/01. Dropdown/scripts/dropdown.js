(function(){
    'use strict';

    $.fn.dropdown = function (){
        var $select = $(this);

        $select.hide();

        var $dropdownContainer = $('<div></div>').addClass('dropdown-list-container')
                                                 .appendTo($select.parent());

        var $dropdownOptions = $('<ul></ul>').addClass('dropdown-list-options')
                                             .appendTo($dropdownContainer);

        $select.children('option').each(function(){
            var $value = $(this).attr('value'),
                $text = $(this).text();

            $('<li></li>').addClass('dropdown-list-option')
                          .attr('data-value', $value)
                          .text($text).appendTo($dropdownOptions);
        });

        $dropdownOptions.on('click', '.dropdown-list-option', function(){
            var $value = $(this).attr('data-value');
            $select.children('option[value="' + $value + '"]').prop('selected', 'selected');
            $select.val($value);
        });

        return $select;
    }

    $('#dropdown').dropdown();
})();
