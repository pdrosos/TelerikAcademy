(function (){
    'use strict';

    $.fn.messageBox = function () {
        var $this = $(this);

        _applyMsgBoxStyles($this);

        return {
            success : function(message){
                $this.css('background-color', '#4ACD4E')
                    .css('color', '#006500')
                    .text(message)
                    .fadeIn(1000, 'linear')
                    .fadeOut(3000, 'swing');
                return $this;
            },
            error : function(message){
                $this.css('background-color', '#CC5045')
                    .css('color', '#690A00')
                    .text(message)
                    .fadeIn(1000, 'linear')
                    .fadeOut(3000, 'swing');
                return $this;
            }
        };

        function _applyMsgBoxStyles(selector) {
            selector.css('width', '30%')
                .css('text-align', 'center')
                .css('line-height', '3em')
                .css('border-radius', '10px');
        };
    };
})();
